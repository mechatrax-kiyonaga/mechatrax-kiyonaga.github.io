#!/bin/bash

sleepi3ctl set extin-trigger 1

