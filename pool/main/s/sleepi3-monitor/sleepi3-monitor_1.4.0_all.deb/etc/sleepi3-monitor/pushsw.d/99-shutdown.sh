#!/bin/bash

shutdown -h now
